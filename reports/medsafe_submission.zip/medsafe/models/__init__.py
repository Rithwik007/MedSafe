"""Validated domain models."""
